#-----------------------------------------------------------------------------
# HYD_EXCHANGE_PARAMS.PL
#
# Contains an array of all of the header values in order for the improved
# exchange format bottle files.
#
# J. Ward	20000.8.3	--> original coding
#----------------------------------------------------------------------------
sub exchange_params
{
	return qw(
	EXPOCODE 
	SECT_ID 
	STNNBR 
	CASTNO 
	SAMPNO 
	BTLNBR 
	DATE 
	TIME 
	LATITUDE 
	LONGITUDE 
	DEPTH 
	CTDPRS 
	CTDTMP 
	CTDSAL 
	SALNTY 
	CTDOXY 
	OXYGEN 
	SILCAT 
	NITRAT 
	NITRIT 
	NO2+NO3 
	PHSPHT 
	CFC-11 
	CFC-12 
	CFC113 
	CCL4 
	TRITUM 
	HELIUM 
	DELHE3 
	DELC14 
	DELC13 
	O18O16 
	TCARBN 
	PCO2 
	ALKALI 
	PH);

}
1;
