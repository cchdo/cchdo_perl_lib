#!/usr/local/bin/perl
#----------------------------------------------------------------
# sub hyd_get_hyddata($filename)
#
# Takes a hyd filename, sum filename, and pointer to the data
# hash.  It calls the sub to read in the sum data.  It then
# reads in the data from the bottle file and combines the data
# from the sum and bottle files into one large hash.  The hash 
# is then sorted and stored into the pointer hash.  
#
# required files:
#	-/home/whpo/jward/src/exchange_format/code/exchange_get_sumdata.pl
#
# params: (0,1,2)
#	0- $hyd file name
#	1- $sum file name
#	2- $hyd_hash pointer
#		- double nested hash {col_name}-> {unit}
#					       -> {data}
#
# returns: (0,1)
#	0- $no_records
#
# J. Ward	2000.7.28	-original coding
# J. Ward	2000.7.31	-made the hash a double nested hash
# 				to hold the units within the hash
#----------------------------------------------------------------
use Fcntl;
use strict;

require "/home/whpo/jjward/src/exchange_format/code/exchange_get_sumdata.pl";

sub hyd_get_hyddata 
{
	
	#params
	my $file_name = shift @_;
	my $sum_file_name = shift @_;
	my $hyd_hash_ptr = shift @_;

	#local vars
	my @buffer = ();
	my @col_name = ();
	my @units = ();
	my $ret_expocode;
	my $num_records = 0;
	my (@cols, $col_no, $line_no);
	my @qual_tags = ();
	my @tmp = ();
	my $er_col;
	my $num_qualt = 0;		
	my $asterisk_format;
	my @asterisk = ();
	my ($stn_no, $cast_no, $press);
	my %tmp_hash;
	my %sum_hash;
	my $press_loc;
	my $qualt_name;



	#
	# open hyd file and place into a buffer
	#
	sysopen (HYD_FILE, $file_name, O_RDONLY) or 
		die "Could not open $file_name for reading. \n";
	@buffer = <HYD_FILE>;
	close(HYD_FILE);
	chomp(@buffer);
	

	# 
	# get the sum file information as a hash
	#
	%sum_hash = get_sumdata($sum_file_name);
  		


	#
	# grab the header information
	#
	my @line = ();
      
	#get expocode
	@line = split(/\s+/, shift(@buffer));
	if (!($line[0]))  {shift(@line);}

	$ret_expocode = $line[1];
	#
	# replace any '/' char with '_' inexpocode
	#
	$ret_expocode =~ s/\//\_/;


	#get col names	
	@col_name = split(/\s+/, shift(@buffer));
	if (!($col_name[0]))   { shift(@col_name);} #get rid of null element


	
	#
	# find the CTDPRS field.  
	#
	my $FOUND_PRS = 0;
	for ($press_loc = 0; $press_loc <= $#col_name; $press_loc++)
	{
		if ($col_name[$press_loc] =~ /CTDPRS/i)
		{
			$FOUND_PRS = 1;
			last;
		}
	}
	if ($FOUND_PRS == 0)
	{
		die "No CTDPRS column exists to sort by, exiting...\n";
	}

	
	
	#
	# get rid of quality field names from the col_name array
	# keep track of number of qualt fields for future use
	#
       	while ($col_name[$#col_name] =~ /QUALT/)
	{
		pop(@col_name); 
		$num_qualt++;
	}
	if ($num_qualt < 1)
	{
		die "No quality code fields found in HYD file!\n";
	}

	$asterisk_format = "a8" x ($#col_name+1);

	#
	#get the units and figure out which params have flags	
	#
	@units = unpack ($asterisk_format, shift(@buffer));
        @asterisk = unpack ($asterisk_format, shift(@buffer));

	#DEBUG
	#print STDOUT "UNIT AND FLAGS:\n";
	#print STDOUT join("|", @col_name),"\n";
	#print STDOUT join("|", @units),"\n";
	#print STDOUT join("|", @asterisk),"\n";


	#
	# put the units into the hyd hash
	#
	for (my $col = 0; $col <= $#col_name; $col++)
	{ 
		#
		# remove trailing and leading white space in units, this
		# is due to the fact that unpack was used and not split
		# by white (must be done this way due to spaces in units)
		#
		$units[$col] =~ s/^\s+//;
		$units[$col] =~ s/\s+$//;

		$hyd_hash_ptr->{$col_name[$col]}{'unit'} = $units[$col];
	}

 	#
	# check the format of the data in the hyd file
	# (check that the number of cols are the same 
	# throughtout)
	# calls function -> local
	#
	if (check_hyd_file(\@buffer))
	{
		die "exiting...\n";
	}

	#
	# set the number of records to return to the last index of the buffer+1
	#
	$num_records = $#buffer+1;

	# vars used in for loop
	my @qualt_flags_1 = ();
	my @qualt_flags_2 = ();
	my $qualt_count;
	my $i;
	my $buffer_length = @buffer;
	my %sum_data = ();
	my ($stn_no, $cast_no);
	my $sum_cast_no;
	my @cast_problem = ();
	#my @other_cast_no = ();

	#
	# create the data hash..it involves building a hash that has a 
	# set of keys for the station , cast , pressure , record number , 
	# and col name.  The reason for this is to quickly sort the large
	# amount of data using three elements.  The record number is there
	# for the case that there is more than one record for the same depth.
	#
	for (my $rec_no=0 ; $rec_no < $buffer_length; $rec_no++)	{
		@tmp = split(/\s+/, shift(@buffer));
		if (!($tmp[0])) { shift(@tmp); }


		
		$stn_no = $tmp[0];
		$cast_no = $tmp[1];
		$press = $tmp[$press_loc];
		
				
		#####################################
		## TAKEN OUT BY J. WARD 2000.8.18 
		#####################################
		# S. Diggs has the probelm of missing cast or station
		# will be noted a this time and the cruise will be skipped
		#
		# check for the sum data..if there is no sum data 
		#
		#if (!(defined($sum_hash{$stn_no}{$cast_no})))
		#{
		#	#
		#	# get the other cast_no's
		#	#
		#	@other_cast_no = 
		#		sort keys %{$sum_hash{$stn_no}};
		#	$sum_cast_no = $other_cast_no[0];
		#}
		#else
		#{
		#	$sum_cast_no = $cast_no;
		#}

		if (!(defined($sum_hash{$stn_no}{$cast_no})))
		{
			push(@cast_problem, "STN: $stn_no CAST:$cast_no");
		}
		$sum_cast_no = $cast_no;

		$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}{'SECT_ID'} = 
			$sum_hash{$stn_no}{$sum_cast_no}{'SECT_ID'};

			
		$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}{'DATE'} =
				$sum_hash{$stn_no}{$sum_cast_no}{'DATE'};
	
		$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}{'TIME'} =
				$sum_hash{$stn_no}{$sum_cast_no}{'TIME'};


		#
		# get the bottom depth..ceck for cor. depth then unc. depth..
		# if none exist then set to -999
		#
		if ((defined($sum_hash{$stn_no}{$sum_cast_no}{'DEPTH_C'})) &&
		( $sum_hash{$stn_no}{$sum_cast_no}{'DEPTH_C'} != 0))
		{
			$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}{'DEPTH'} =
				$sum_hash{$stn_no}{$sum_cast_no}{'DEPTH_C'};
		} 
		elsif ((defined($sum_hash{$stn_no}{$sum_cast_no}{'DEPTH_U'})) &&
		( $sum_hash{$stn_no}{$sum_cast_no}{'DEPTH_U'} != 0))
		{
			$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}{'DEPTH'} =
				$sum_hash{$stn_no}{$sum_cast_no}{'DEPTH_U'};
		}
		else
		{
			$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}{'DEPTH'} = '-999';
		}

		$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}{'LONGITUDE'} =
			$sum_hash{$stn_no}{$sum_cast_no}{'LONGITUDE'};

		$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}{'LATITUDE'} =
			$sum_hash{$stn_no}{$sum_cast_no}{'LATITUDE'};


		

		#
		# grab the quality columns
		#
		if ($num_qualt == 2)
		{
			@qualt_flags_2 = split(//, pop(@tmp));
		}
		@qualt_flags_1 = split(//, pop(@tmp));


		$qualt_count = 0;
		for ($i=0 ; $i <= $#col_name ; $i++)	
		{
			#
			# change from -9 to -999 => see exchange format 
			#
			if ($tmp[$i] == -9.0) 
			{
				$tmp[$i] = -999.0;
			}

			$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}{$col_name[$i]} =
				$tmp[$i];

			#if a quality flag is associated with it
			if ($asterisk[$i] =~ /\*\*\*/)
			{
				if (!(defined($qualt_flags_1[$qualt_count])) ||
				(($num_qualt == 2) && (!(defined($qualt_flags_2[$qualt_count])))))
				{
					die "The bottle file does not have the correct number of flags.\n";
				}

				$qualt_name = "$col_name[$i]".'_FLAG_W';

				if ($num_qualt == 2)
				{
					if (($qualt_flags_2[$qualt_count] == 1)&&($qualt_flags_1[$qualt_count] != 1))
					{
						$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}{$qualt_name} = 
							$qualt_flags_1[$qualt_count];
					}
					else
					{
						$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}{$qualt_name} = 
							$qualt_flags_2[$qualt_count];
					}
				}
				else
				{
					$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}{$qualt_name} =
						$qualt_flags_1[$qualt_count];
				}
				$qualt_count++; 
			}		
		}
	}#end for


	if ($#cast_problem >= 0)
	{
		print "No sum data was found for:\n";
		print join("\n", @cast_problem);
		print "\n";
		die "exiting...\n";
	}


		

	#
	# sort into final format, sort in numerical order station->cast->pressure 
	#
	my $counter = 0;
	my $rec_no;
	my $elem;
	foreach $stn_no (sort {$a cmp $b} keys(%tmp_hash))
	{
		foreach $cast_no (sort {$a <=> $b} keys(%{$tmp_hash{$stn_no}}))
		{
			foreach $press (sort {$a <=> $b} keys(%{$tmp_hash{$stn_no}{$cast_no}}))
		 	{
				#print "STN: $stn_no CAST: $cast_no PRES: $press\n";
				foreach $rec_no ( sort {$a <=> $b} keys(%{$tmp_hash{$stn_no}{$cast_no}{$press}}))
				{
					foreach $elem ( keys %{$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}} )
					{
						#print  $elem.':'.$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}{$elem}.",";
						$hyd_hash_ptr->{$elem}{'data'}[$counter] = 
							$tmp_hash{$stn_no}{$cast_no}{$press}{$rec_no}{$elem};		
					}
					$counter++;
					#print "\n";
				}

			}
		}
	}


	#


	#
	# there is only one expocode for each file 
	#
	$hyd_hash_ptr->{'EXPOCODE'}{'data'} = $ret_expocode;


	return ($num_records); 
}





#--------------------------------------------------------------------
# S. Diggs mod. by J. Ward
#
# 	Checks the number of columns to see if they are the
# 	same throughout, they should be!
#
#	Returns
#		- 0 - file is ok
#		- 1 - file is bad
#--------------------------------------------------------------------
sub check_hyd_file
{
	#param
	my $buffer_ptr = shift(@_);

	#vars
	my ($x , $old_num_fields, @tmp);
	my $ret_stat = 0;

	@tmp = split(/\s+/, $buffer_ptr->[0]);
	$old_num_fields = $#tmp;
	for ($x=1 ; $x <=  $#{$buffer_ptr} ; $x++)     {

        	@tmp = split /\s+/,$buffer_ptr->[$x];
        	if (($#tmp != $old_num_fields) && ($x > 4))     {
			print STDOUT "HYD file problem data line: $x\n"; 
			$ret_stat = 1;
        	}
	}
	return $ret_stat;

}
1;

