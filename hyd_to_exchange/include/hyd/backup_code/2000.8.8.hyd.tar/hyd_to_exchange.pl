#!/usr/local/bin/perl
#--------------------------------------------------------------
# HYD_TO_EXCHANGE.PL
#
# This script takes HYD file and converts it to the 
# improved exchange file format.  The conversion is
# based on varsion 2000.07.18 of the Improved Exchange
# Format manual written by James Swift and edited
# by Stephen Diggs.
#
# The script takes in two arguments, the HYD and SUM
# files, extracts the needed data into a hash.  The data
# is then checked and the desired columns are printed to
# the new exchange file.  The desired columns are stored in
# an array in hyd_excahnge_params.pl.  The array is in the 
# order that was chosen by Jim Swift and Sarilee Anderson.
#
#
# Required files
#	-/home/whpo/jjward/src/exchange_format/code/hyd/hyd_get_hyddata.pl
#	-/home/whpo/jjward/src/tools/PERL/get_decplaces.pl
#	-/home/whpo/jjward/src/exchange_format/code/hyd/hyd_exchange_params.pl
#	-/home/whpo/jjward/src/exchange_format/code/exchange_param_format.pl
#	-/home/whpo/jjward/src/exchange_format/code/get_whpo_timestamp.pl
#
#
# J. Ward <jjward@ucsd.edu> --> original coding 
# J. Ward	8.3.2000    --> added check for correct number of cols
#				in hyd file
#
# Last modified 8.4.2000
#---------------------------------------------------------------

use strict;
use Fcntl;
use File::stat;
use Time::localtime;

require "/home/whpo/jjward/src/exchange_format/code/hyd/hyd_get_hyddata.pl";
require "/home/whpo/jjward/src/tools/PERL/get_decplaces.pl";
require "/home/whpo/jjward/src/exchange_format/code/hyd/hyd_exchange_params.pl";
require "/home/whpo/jjward/src/exchange_format/code/exchange_param_format.pl";
require "/home/whpo/jjward/src/exchange_format/code/get_whpo_timestamp.pl";


my ($hyd_name, $sum_name, $output_file); 
my $expocode;
my %hyd_hash = ();
my %sum_hash = ();
my $hyd_size = 0;
my @sum_buffer = ();
my %format = ();
my @hyd_header = ();


#
# read in the HYD fle name from the command line or ask
# for it if not present
#
if ($#ARGV >= 0)
{	
	$hyd_name = shift(@ARGV);
	chomp($hyd_name);
}
else 
{
	#PROMP user for the name
	do {
		print STDERR "Enter the name of the HYD file: ";
		$hyd_name = <STDIN>;
		chomp($hyd_name);
	
	}until (-e $hyd_name);
}	

#
# read in the SUM file name from the command line or ask
# for it if not present
#
if ($#ARGV >= 0)
{	
	$sum_name = shift(@ARGV);
	chomp($sum_name);
}
else
{
	do {
		print STDERR "Enter the name of the SUM file: ";
		$sum_name = <STDIN>;
		chomp($sum_name);
	}until (-e $sum_name);
}



print STDOUT "Reading input from files...\n";

#
# call the function to read in the data and header info from the HYD file
#
($hyd_size) = hyd_get_hyddata($hyd_name,$sum_name, \%hyd_hash);



#
# Check to see if the new filename exists, if so ask if it is ok to write
# over the file.  If yes then delete file and open the new file with the 
# same name.
#
my $y_n;
my $output_name = "$hyd_name".'.hy1.csv';
if (-e $output_name) {
        print STDOUT "Output file $output_file exists, overwrite [y/n]: ";
	do {
	        $y_n = <STDIN>;
	} until ($y_n =~ /y|n/i);
	if (!($y_n =~ /y/i))
	{
	    die "File was not touched..exiting\n";
	}
	else
	{
	    #delete the file to write over
	    unlink($output_name) or die "Could not write over file: $output_name\n";
	}
}

my $whpo_stamp = get_timestamp();

print STDOUT "Writing header info to file...\n";

sysopen (OUTPUT, $output_name, O_WRONLY|O_CREAT) or 
		die "Could not open $output_name for writing. \n";

#
# Print info at top for tracking data errors
#  -code that wrote the file
#  -original hyd file date/time stamp
#  -original sum file date/time stamp
#
my $mtime_hyd = ctime(stat($hyd_name)->mtime);
my $mtime_sum = ctime(stat($sum_name)->mtime);
print OUTPUT "BOTTLE, $whpo_stamp\n";
print OUTPUT '#'."code : jjward hyd_to_exchange.pl V1.0\n";
print OUTPUT '#'."original HYD file: $hyd_name   $mtime_hyd\n";
print OUTPUT '#'."original SUM file: $sum_name   $mtime_sum\n";

	
#
# Get the exact params in the correct order for the new format
#
my @exact_headers = exchange_params();
my $header;

#
# go through the array of exact_headers and see if each has data
# in the hash, if the header exists in the hash then place on 
# hyd_header hash.
#
my $flag_name;
my @cols_removed;
foreach $header(@exact_headers)
{
	if (defined($hyd_hash{$header})) {push(@hyd_header, $header);}
	$flag_name = $header.'_FLAG_W';
	if (defined($hyd_hash{$flag_name})) {push(@hyd_header, $flag_name);}
}

#
# go through and print out the col headers that were left out
#
my $found = 0;

print STDOUT "The following columns are not going to be included:\n";
print STDOUT "----------------------------------------------------\n";
foreach my $elem(sort keys %hyd_hash)
{
	$found = 0;
	foreach my $header(@hyd_header)
	{
		if ($header eq $elem)
		{
			$found = 1;
			last;	
		}
	}
	if ($found == 0)
	{ 	print STDOUT "\t$elem\n";}
}
print STDOUT "----------------------------------------------------\n";

print STDOUT "Writing data to file...\n";
#
# print the header
#
print OUTPUT join(",", @hyd_header),"\n";

#
#print units
#
my @units_output;
foreach $header(@hyd_header)
{
	if (exists($hyd_hash{$header}{'unit'}))
	{
		push(@units_output, $hyd_hash{$header}{'unit'});
	}
	else 
	{
		push(@units_output, '');
	}
}
print OUTPUT join(",", @units_output),"\n";

#
# print data
#
my @data_output;

#
# get the format for the columns 
#
%format = exchange_param_format();

for (my $i = 0; $i <$hyd_size; $i++)
{
        @data_output = ();
        foreach my $elem (@hyd_header)
        {
                if ($elem eq 'EXPOCODE')
                {
                        push(@data_output, $hyd_hash{$elem}{'data'});
                }
                elsif ($elem =~ /_FLAG_W/)
                {
                        push(@data_output, sprintf("%1d", $hyd_hash{$elem}{'data'}[$i]));
                }
                else
                {
                        push(@data_output, sprintf($format{$elem}, $hyd_hash{$elem}{'data'}[$i]));
                }
        }
        print OUTPUT join(",", @data_output), "\n";
}




print OUTPUT "END_DATA";
close(OUTPUT);
print STDOUT "The exchange file was created: $output_name\n";
 
